import subprocess
import sys
import os
import platform
import logging
import re
import argparse

# Regular expression to match ANSI escape sequences
ansi_escape = re.compile(r'\x1B[@-_][0-?]*[ -/]*[@-~]')

class StripAnsiFilter(logging.Filter):
    def filter(self, record):
        record.msg = ansi_escape.sub('', record.msg)
        return True

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Console handler with ANSI color codes
console_handler = logging.StreamHandler()
console_handler.setLevel(logging.INFO)
console_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
logger.addHandler(console_handler)

# File handler without ANSI color codes
file_handler = logging.FileHandler("install_bundle_script.log")
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
file_handler.addFilter(StripAnsiFilter())
logger.addHandler(file_handler)

logger.info(f"Current Working Directory: {os.getcwd()}")

def run_command(command, use_sudo=False):
    if use_sudo and platform.system() != 'Windows':
        command = 'sudo ' + command
    logger.info(f"Running command: {command}")
    try:
        result = subprocess.run(command, shell=True, check=True, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        logger.info(result.stdout)
        return result.stdout
    except subprocess.CalledProcessError as e:
        logger.error(f"An error occurred while running command: {command}")
        logger.error(e.stdout)
        sys.exit(1)

def install_all_packages_in_directory():
    package_list = [f for f in os.listdir('.') if os.path.isfile(f) and (f.endswith(".zip") or f.endswith(".whl"))]
    logger.info(f"Package list to install: {package_list}")
    for package in package_list:
        cmd = f"pip install --force-reinstall {package}"
        logger.info(f"Running command: {cmd}")
        try:
            output = subprocess.check_output(cmd, shell=True, text=True)
            logger.info(output)
        except subprocess.CalledProcessError as e:
            logger.error(f"An error occurred while running command: {cmd}")
            logger.error(e.output)
            sys.exit(1)

def uninstall_appium_drivers():
    # Run the command to list installed drivers
    output = run_command('appium driver ls')
    
    if output is None:
        logger.error("Failed to retrieve the list of installed drivers.")
        sys.exit(1)
    
    # Debug log the output
    logger.debug(f"Output of 'appium driver ls':\n{output}")
    
    # Remove ANSI escape sequences
    cleaned_output = ansi_escape.sub('', output)
    
    # Parse the cleaned output to find installed drivers
    installed_drivers = re.findall(r'- (\w+)@\d+\.\d+\.\d+ \[installed', cleaned_output)
    
    # Debug log the installed drivers
    logger.debug(f"Installed drivers found: {installed_drivers}")
    
    # Uninstall each installed driver
    for driver in installed_drivers:
        run_command(f'appium driver uninstall {driver}')

def main(args):
    # Step 1: Upgrade pip
    run_command('python -m pip install --upgrade pip')

    # Step 2: Uninstall selenium and robotframework-seleniumlibrary
    run_command('pip uninstall -y selenium')
    run_command('pip uninstall -y robotframework-seleniumlibrary')

    # Step 3: Install requirements from InternalPackages/requirements.txt
    run_command('pip install --upgrade -r requirements.txt')

    # Step 4: Install playwright
    run_command('python -m playwright install')

    # Step 5: Clean and initialize rfbrowser
    run_command('rfbrowser --silent clean-node')
    run_command('rfbrowser --silent init')

    # Step 6: Run SWS_Bundle_installer.py
    os.chdir('InternalPackages')
    install_all_packages_in_directory()
    os.chdir('..')

    # Check if we should exclude device-related steps
    if not args.exclude_device:
        # Step 7: Uninstall and reinstall appium globally using npm with sudo if needed
        run_command('npm uninstall -g --silent --no-progress --loglevel=error appium', use_sudo=True)
        run_command('npm install -g --silent --no-progress --loglevel=error appium', use_sudo=True)

        # Step 8: Uninstall only installed appium drivers
        uninstall_appium_drivers()
        run_command('appium driver install uiautomator2')

        # Step 9: Uninstall and reinstall kill-port globally using npm with sudo if needed
        run_command('npm uninstall -g --silent --no-progress --loglevel=error kill-port', use_sudo=True)
        run_command('npm install -g --silent --no-progress --loglevel=error kill-port', use_sudo=True)

        # Step 10: List node and appium information    
        run_command('appium -v')
        run_command('appium driver ls')
        run_command('npm ls -g')
        run_command('npm ls')

    # Step 11: List pip packages
    run_command('pip list')
    # Final Step: Print confirmation message
    logger.info("Bundle Installed Successfully!")

if __name__ == "__main__":
    # Set up argument parsing
    parser = argparse.ArgumentParser(description="Install and configure the required packages and tools.")
    parser.add_argument('--exclude_device', action='store_true', help="Exclude device-related steps (steps 7 to 10).")
    args = parser.parse_args()

    main(args)
